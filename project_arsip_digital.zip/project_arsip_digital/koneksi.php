<?php 

$koneksi = mysqli_connect("localhost", "root", "" ,"project_arsip_digital");

?>